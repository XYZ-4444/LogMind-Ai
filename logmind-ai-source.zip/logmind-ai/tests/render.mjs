import assert from 'node:assert/strict';
import { createServer } from 'vite';
import { createElement } from 'react';
import { renderToString } from 'react-dom/server';
import { seedOrg, ORGANIZATIONS, groupIncidents, authenticate } from '../src/engine.js';

// SSR has no browser storage; provide an isolated empty store for the sign-in check.
Object.defineProperty(globalThis, 'localStorage', { value: { getItem: () => null }, configurable: true });
Object.defineProperty(globalThis, 'sessionStorage', { value: { getItem: () => null }, configurable: true });

const server = await createServer({ server: { middlewareMode: true, hmr: false, ws: false }, appType: 'custom' });
try {
  const investigation = await server.ssrLoadModule('/src/investigation.jsx');
  const management = await server.ssrLoadModule('/src/management.jsx');
  const { default: App } = await server.ssrLoadModule('/src/App.jsx');
  const data = seedOrg('shopsphere');
  const incidents = groupIncidents(data.logs, {}, data.orgId);
  const noop = () => {};
  const props = { data, logs: data.logs, org: ORGANIZATIONS[0], incidents, allIncidents: incidents, incident: incidents[0], session: authenticate('demo@logmind.local', 'Demo123!', data.orgId), isAdmin: true, hours: 'all', preset: {}, update: noop, notify: noop, openIncident: noop, openLogs: noop, navigate: noop, onHistory: noop, feedback: noop, updateIncident: noop, onReset: noop };
  for (const [name, Component] of Object.entries({ SignInApp: App, ...investigation, ...management }).filter(([name]) => !['download'].includes(name))) {
    const html = renderToString(createElement(Component, props));
    assert.ok(html.length > 0, `${name} must render content`);
    assert.ok(!html.includes('Something interrupted this demo'), `${name} must not render the error boundary`);
    console.log(`PASS render: ${name}`);
  }
} finally {
  await server.close();
}
