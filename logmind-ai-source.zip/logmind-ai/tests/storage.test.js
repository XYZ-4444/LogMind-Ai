import test from 'node:test';
import assert from 'node:assert/strict';
import { seedOrg, authenticate } from '../src/engine.js';
import { loadOrganization, saveOrganization, getSession, saveSession } from '../src/storage.js';

function storage() {
  const values = new Map();
  return { getItem: key => values.get(key) ?? null, setItem: (key, value) => values.set(key, String(value)), removeItem: key => values.delete(key), clear: () => values.clear() };
}
Object.defineProperty(globalThis, 'localStorage', { value: storage(), configurable: true });
Object.defineProperty(globalThis, 'sessionStorage', { value: storage(), configurable: true });

test('saving one organization cannot change another organization’s records', () => {
  localStorage.clear();
  const a = seedOrg('shopsphere'), b = seedOrg('cloudnova');
  saveOrganization(a); saveOrganization(b);
  saveOrganization({ ...a, feedback: { sample: { helpful: true } }, logs: a.logs.slice(0,5) });
  assert.equal(loadOrganization('shopsphere').logs.length, 5);
  assert.equal(loadOrganization('cloudnova').logs.length, b.logs.length);
  assert.deepEqual(loadOrganization('cloudnova').feedback, {});
});

test('mixed organization records are rejected on save and safely reseeded on load', () => {
  const d = seedOrg('shopsphere');
  const bad = { ...d, logs: seedOrg('cloudnova').logs };
  assert.throws(() => saveOrganization(bad), /Organization mismatch/);
  localStorage.setItem('logmind-demo-v1:shopsphere', JSON.stringify(bad));
  assert.ok(loadOrganization('shopsphere').logs.every(l => l.orgId === 'shopsphere'));
  assert.throws(() => loadOrganization('unknown-org'), /Unknown/);
});

test('remember-me sessions omit passwords and logout clears both session stores', () => {
  const session = authenticate('demo@logmind.local', 'Demo123!', 'securegate');
  saveSession(session, true);
  assert.equal(getSession().orgId, 'securegate');
  assert.equal(getSession().remember, true);
  assert.ok(!localStorage.getItem('logmind-demo-v1:session').includes('Demo123!'));
  saveSession(session, false);
  assert.equal(localStorage.getItem('logmind-demo-v1:session'), null);
  assert.equal(getSession().remember, false);
  saveSession(null);
  assert.equal(getSession(), null);
});

test('stored role and membership claims are not trusted even in the mock session', () => {
  saveSession({ email: 'engineer@logmind.local', orgId: 'cloudnova', role: 'admin' }, true);
  assert.equal(getSession(), null);
  saveSession({ email: 'engineer@logmind.local', orgId: 'shopsphere', role: 'admin' }, true);
  assert.equal(getSession().role, 'engineer');
  assert.deepEqual(getSession().memberships, ['shopsphere']);
  saveSession(null);
});
