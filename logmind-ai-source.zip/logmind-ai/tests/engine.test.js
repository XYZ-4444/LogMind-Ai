import test from 'node:test';
import assert from 'node:assert/strict';
import { ORGANIZATIONS, authenticate, seedOrg, parseLogs, classify, normalize, redact, groupIncidents, historicalMatches, prioritize, paymentScenario, filterLogs, csvCell, incidentsCSV, SEVERITY } from '../src/engine.js';

const now = Date.now();
const org = 'shopsphere';
const seed = seedOrg(org, now);

test('mock authentication enforces configured memberships and rejects wrong passwords', () => {
  assert.equal(authenticate('demo@logmind.local', 'wrong', org), null);
  assert.equal(authenticate('engineer@logmind.local', 'Demo123!', 'cloudnova'), null);
  assert.equal(authenticate('engineer@logmind.local', 'Demo123!', org).role, 'engineer');
  const admin = authenticate('demo@logmind.local', 'Demo123!', 'securegate');
  assert.equal(admin.role, 'admin');
  assert.equal('password' in admin, false);
});

test('each organization has distinct, internally scoped logs and five useful history records', () => {
  const counts = new Set();
  for (const o of ORGANIZATIONS) {
    const d = seedOrg(o.id, now);
    counts.add(d.logs.length);
    assert.ok(d.logs.every(l => l.orgId === o.id));
    assert.equal(d.history.length, 5);
    assert.ok(d.history.every(h => h.orgId === o.id && h.steps.length && h.rootCause && h.messages.length));
    for (const level of Object.keys(SEVERITY)) assert.ok(d.logs.some(l => l.severity === level));
  }
  assert.equal(counts.size, 3);
});

test('plain text parsing extracts timestamps, severity, service and trace IDs', () => {
  const result = parseLogs('2026-10-09T15:00:00Z ERROR [postgres-db] Database connection refused trace_id=abc\n2026-10-09T15:00:01Z WARN service=edge-proxy upstream unavailable', org, now);
  assert.equal(result.logs.length, 2);
  assert.equal(result.logs[0].timestamp, Date.parse('2026-10-09T15:00:00Z'));
  assert.equal(result.logs[0].service, 'postgres-db');
  assert.equal(result.logs[0].traceId, 'abc');
  assert.equal(result.logs[0].kind, 'database');
  assert.equal(result.logs[1].severity, 'WARNING');
  assert.equal(result.logs[1].service, 'edge-proxy');
  assert.equal(result.inferredTimestamps, 0);
});

test('structured parsing handles JSON lines and prevents uploaded tenant selection', () => {
  const { logs } = parseLogs(JSON.stringify({ orgId: 'cloudnova', timestamp: '2026-10-09T15:00:00Z', level: 'fatal', service: 'payments', message: 'Payment request timeout', trace_id: 'sample' }), org, now);
  assert.equal(logs[0].orgId, org);
  assert.equal(logs[0].severity, 'CRITICAL');
  assert.equal(logs[0].kind, 'payment');
  assert.equal(logs[0].traceId, 'sample');
});

test('missing timestamps and unstructured records are counted honestly', () => {
  const r = parseLogs('ERROR database unavailable\nan ordinary message\n{broken json', org, now);
  assert.equal(r.inferredTimestamps, 3);
  assert.equal(r.unstructuredLines, 2);
  assert.ok(r.logs.every(l => l.timestampInferred));
  assert.equal(r.logs[1].severity, 'INFO');
});

test('empty and excessive files are rejected', () => {
  assert.throws(() => parseLogs(' \n\r\n', org), /no log entries/);
  assert.throws(() => parseLogs(Array(10001).fill('INFO ok').join('\n'), org), /10,000/);
});

test('HTML-like log content remains inert text for React to escape', () => {
  const message = '<img src=x onerror=alert(1)> ERROR payment failed';
  assert.equal(parseLogs(message, org).logs[0].message, message);
});

test('basic redaction removes common key-value secrets and bearer credentials', () => {
  const result = redact('password=hunter2 api_key=sk123 token=abc Bearer eyJ.secret');
  assert.ok(!result.includes('hunter2'));
  assert.ok(!result.includes('sk123'));
  assert.ok(!result.includes('eyJ.secret'));
  assert.equal((result.match(/REDACTED/g) || []).length, 4);
});

test('normalization tolerates variable counts and addresses', () => {
  assert.equal(normalize('Database timeout after 5000 ms at 10.2.3.4'), normalize('Database timeout after 1000 ms at 10.5.9.2'));
});

test('rule-based grouping isolates organizations even if mixed input is supplied', () => {
  const mixed = [...seed.logs, ...seedOrg('cloudnova', now).logs];
  const incidents = groupIncidents(mixed, {}, org);
  assert.ok(incidents.length);
  assert.ok(incidents.every(i => i.orgId === org && i.logs.every(l => l.orgId === org)));
  assert.equal(incidents.reduce((sum,i) => sum + i.logs.length, 0), seed.logs.filter(l => SEVERITY[l.severity] >= 3).length);
  assert.ok(incidents.every((i,n) => n === 0 || incidents[n - 1].score >= i.score));
});

test('unclassified errors with different normalized messages remain separate', () => {
  const { logs } = parseLogs('ERROR [worker] missing template foo\nERROR [worker] disk full\nERROR [worker] missing template foo', org, now);
  const incidents = groupIncidents(logs, {}, org);
  assert.equal(incidents.length, 2);
  assert.equal(incidents.find(i => i.title.includes('missing template')).logs.length, 2);
});

test('priority factors sum to the reported score and impact affects ranking', () => {
  const base = { orgId: org, severity: 'ERROR', service: 'service', timestamp: now, message: 'Failure' };
  const network = prioritize([{ ...base, kind: 'network' }], now);
  const payment = prioritize([{ ...base, kind: 'payment' }], now);
  assert.equal(payment.score, network.score + 15);
  assert.equal(payment.score, payment.factors.reduce((n,f) => n + f.value, 0));
  assert.ok(payment.score >= 0 && payment.score <= 100);
});

test('ranking uses rising frequency and duration in addition to volume', () => {
  const logs = Array.from({ length: 10 }, (_,i) => ({ kind: 'database', severity: 'ERROR', service: 'db', timestamp: now - i * 60000 }));
  const p = prioritize(logs, now);
  assert.equal(p.factors[3].value, 15);
  assert.equal(p.factors[5].value, 0);
  const long = prioritize([...logs, { ...logs[0], timestamp: now - 120 * 60000 }], now);
  assert.equal(long.factors[5].value, 10);
});

test('stored historical content actually drives matching; foreign and failed cases cannot match', () => {
  const incident = groupIncidents(seed.logs, {}, org).find(i => i.kind === 'database');
  const matches = historicalMatches(incident, seed.history);
  assert.equal(matches[0].kind, 'database');
  assert.equal(matches[0].score, 100);
  assert.ok(matches[0].steps[0].includes('connections'));
  assert.equal(historicalMatches(incident, seedOrg('cloudnova', now).history).length, 0);
  assert.equal(historicalMatches(incident, seed.history.map(h => ({ ...h, worked: false }))).length, 0);
  assert.equal(historicalMatches(incident, seed.history.map(h => ({ ...h, messages: ['mysterious purple elephant'] }))).length, 0);
});

test('an unknown pattern produces no reliable historical match', () => {
  const incident = groupIncidents(parseLogs('ERROR [renderer] missing banana template glyph', org, now).logs, {}, org)[0];
  assert.equal(historicalMatches(incident, seed.history).length, 0);
});

test('an incident is not its own historical match after resolution', () => {
  const incident = groupIncidents(seed.logs, {}, org)[0];
  const record = { ...seed.history[0], id: `resolved:${incident.id}`, kind: incident.kind, service: incident.services[0], messages: [incident.logs[0].message] };
  assert.equal(historicalMatches(incident, [record]).length, 0);
});

test('payment demo preserves one request trace and first database failure', () => {
  const logs = paymentScenario(org, now);
  assert.equal(logs.length, 6);
  assert.equal(new Set(logs.map(l => l.traceId)).size, 1);
  const first = logs.find(l => SEVERITY[l.severity] >= 4);
  assert.equal(first.kind, 'database');
  assert.ok(first.timestamp < logs.find(l => l.message.includes('threshold')).timestamp);
  assert.equal(groupIncidents(logs, {}, org).reduce((n,i) => n + i.logs.length, 0), 4);
});

test('filters combine category, service, severity, search, date range and sorting', () => {
  const rows = filterLogs(seed.logs, { type: 'DATABASE', severity: 'ERROR', service: 'postgres-db', search: 'timeout', hours: 'all', direction: 'asc' });
  assert.ok(rows.length > 0);
  assert.ok(rows.every(l => l.kind === 'database' && l.service === 'postgres-db' && l.severity === 'ERROR'));
  assert.ok(rows.every((l,i) => i === 0 || rows[i - 1].timestamp <= l.timestamp));
  assert.ok(filterLogs(seed.logs, { hours: '1' }).length < filterLogs(seed.logs, { hours: '24' }).length);
  assert.equal(filterLogs(seed.logs, { search: 'never appears xyz' }).length, 0);
  const sorted = filterLogs(seed.logs, { sort: 'severity', direction: 'desc' });
  assert.ok(sorted.every((l,i) => i === 0 || SEVERITY[sorted[i - 1].severity] >= SEVERITY[l.severity]));
});

test('CSV encoding resists spreadsheet formulas and quotes commas correctly', () => {
  for (const value of ['=HYPERLINK("x")', '+cmd', '-cmd', '@cmd', '  =cmd', '\tcmd']) assert.ok(csvCell(value).startsWith('"\''));
  assert.equal(csvCell('hello, "world"'), '"hello, ""world"""');
  const incidents = groupIncidents(seed.logs, {}, org);
  const csv = incidentsCSV(incidents);
  assert.equal(csv.split('\r\n').length, incidents.length + 1);
  assert.ok(csv.includes('"Organization"'));
  assert.ok(csv.includes('"shopsphere"'));
});
